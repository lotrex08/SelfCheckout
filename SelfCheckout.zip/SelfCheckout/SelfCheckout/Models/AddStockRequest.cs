﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using System.Xml.Linq;

namespace SelfCheckout.Models
{   
    public class AddStockRequest
    {
        public int _20000 { get; set; }
        public int _10000 { get; set; }
        public int _5000 { get; set; }
        public int _2000 { get; set; }
        public int _1000 { get; set; }
        public int _500 { get; set; }
        public int _200 { get; set; }
        public int _100 { get; set; }
        public int _50 { get; set; }
        public int _20 { get; set; }
        public int _10 { get; set; }
        public int _5 { get; set; }
    }
}
