﻿using Microsoft.EntityFrameworkCore;
using SelfCheckout.Models;
using System.Diagnostics.CodeAnalysis;
using System.Security.Cryptography.Xml;

namespace SelfCheckout.Data
{
    public class SelfCheckoutAPIDbContext : DbContext
    {
        public SelfCheckoutAPIDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Stock> Stocks { get; set; }
    }
}
