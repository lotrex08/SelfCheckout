﻿using Microsoft.AspNetCore.Mvc;
using SelfCheckout.Data;
using SelfCheckout.Models;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;

namespace SelfCheckout.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    public class StockController : Controller
    {
        private readonly SelfCheckoutAPIDbContext dbContext;

        public StockController(SelfCheckoutAPIDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult GetStock()
        {
            return Ok(dbContext.Stocks.ToList());
        }

        [HttpPost]
        public async Task<IActionResult> AddStock([FromBody] JsonElement body)
        {
            //string asd = body.ToString();
            string data = System.Text.Json.JsonSerializer.Serialize(body);
            if (data == null) return BadRequest();

            var dict = JsonSerializer.Deserialize<Dictionary<string, int>>(data);
            List<string> keyList = new List<string>(dict.Keys);
            
            var stock = new Stock()
            {
                _20000 = 0,
                _10000 = 0,
                _5000 = 0,
                _2000 = 0,
                _1000 = 0,
                _500 = 0,
                _200 = 0,
                _100 = 0,
                _50 = 0,
                _20 = 0,
                _10 = 0,
                _5 = 0
            };

            foreach(var key in dict.Keys)
            {
                if (key == "5") stock._5 += dict[key];
                else if (key == "10") stock._10 += dict[key];
                else if (key == "20") stock._20 += dict[key];
                else if (key == "50") stock._50 += dict[key];
                else if (key == "100") stock._100 += dict[key];
                else if (key == "200") stock._200 += dict[key];
                else if (key == "500") stock._500 += dict[key];
                else if (key == "1000") stock._1000 += dict[key];
                else if (key == "2000") stock._2000 += dict[key];
                else if (key == "5000") stock._5000 += dict[key];
                else if (key == "10") stock._10 += dict[key];
                else return BadRequest();
            }

            
            await dbContext.Stocks.AddAsync(stock);
            await dbContext.SaveChangesAsync();
            

            return Ok(dict);
        }
    }
}
