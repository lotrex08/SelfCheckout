﻿using Microsoft.AspNetCore.Mvc;
using SelfCheckout.Data;
using System.Text.Json;

namespace SelfCheckout.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    public class CheckoutController : Controller
    {
        private readonly SelfCheckoutAPIDbContext dbContext;

        public CheckoutController(SelfCheckoutAPIDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpPost]
        public async Task<IActionResult> AddCheckout([FromBody] JsonElement body)
        {
            string data = System.Text.Json.JsonSerializer.Serialize(body);
            if (data == null) return BadRequest();

            var dict = JsonSerializer.Deserialize<Dictionary<string, int>>(data);

            int availableMoney = 0;
            Dictionary<int,int> availableBills = new Dictionary<int,int>();

            foreach (var key in dict.Keys)
            {
                if (key == "price") break;
                availableMoney += dict[key] * Convert.ToInt32(key);
                availableBills.Add(Convert.ToInt32(key),dict[key]);
            }

            if(dict["price"] > availableMoney) return BadRequest();

            int change = availableMoney - dict["price"];

            var checkout = await dbContext.Stocks.FindAsync(1);

            int pay = dict["price"];

            if (checkout != null)
            {
                
            }
            else return BadRequest();

            Dictionary<string, int> changeBills = new Dictionary<string, int>();


            return Ok(change);
        }

    }
}
